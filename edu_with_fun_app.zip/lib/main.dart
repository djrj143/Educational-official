
import 'package:flutter/material.dart';

void main() => runApp(EduWithFunApp());

class EduWithFunApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Edu with Fun',
      theme: ThemeData(
        primaryColor: Color(0xFFCDB4DB),
        scaffoldBackgroundColor: Color(0xFFF7F3F9),
        textTheme: TextTheme(bodyLarge: TextStyle(color: Colors.black)),
      ),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFCDB4DB),
        title: Text('Edu with Fun'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 16,
          crossAxisSpacing: 16,
          children: [
            _buildSection(context, 'Videos', Icons.play_circle_fill),
            _buildSection(context, 'Notes', Icons.note),
            _buildSection(context, 'Tests', Icons.assignment),
            _buildSection(context, 'Premium', Icons.lock),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(BuildContext context, String title, IconData icon) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 4,
      color: Color(0xFFFFC8DD),
      child: InkWell(
        onTap: () {
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('$title section coming soon!')));
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.white),
            SizedBox(height: 10),
            Text(title,
                style: TextStyle(fontSize: 18, color: Colors.white)),
          ],
        ),
      ),
    );
  }
}
